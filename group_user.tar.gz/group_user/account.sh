swauth-add-account -K swauthkey Backup -G 'male,female,doctor1,doctor2,doctor3,doctor4,doctor5,professor,associate_professor,lectuer,headman,monitor,security,system_structure,massive_sotrage,big_data,hust' -I 'backup group for some student'

swauth-add-account -K swauthkey Security -G 'male,female,doctor1,doctor2,doctor3,doctor4,doctor5,professor,associate_professor,lectuer,headman,monitor,security,system_structure,massive_sotrage,big_data,hust' -I 'security group for cloud storage'

swauth-add-account -K swauthkey BigData -G 'male,female,doctor1,doctor2,doctor3,doctor4,doctor5,professor,associate_professor,lectuer,headman,monitor,security,system_structure,massive_sotrage,big_data,hust' -I 'bigdata group for mechine learning'
