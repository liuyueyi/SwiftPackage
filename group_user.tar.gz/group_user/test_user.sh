swauth-add-user -K swauthkey -a Bob Bob Bob -G 'Backup,Bigdata,Security,Storage,School'
swauth-add-user -K swauthkey -a Backup Bob Bob -I 'male,associate_professor,security,hust'
swauth-add-user -K swauthkey -a Bigdata Bob Bob -I 'male,hust,big_data,massive_sotrage'
swauth-add-user -K swauthkey -a Security Bob Bob -I 'male,security,system_structure,lectuer'

swauth-add-user -K swauthkey -a Angle Angle Angle -G 'Backup,Security'
swauth-add-user -K swauthkey -a Backup Angle Angle -I 'female doctor4 headman massive_sotrage hust'
swauth-add-user -K swauthkey -a Security Angle Angle -I 'female doctor4 security hust'

swauth-add-user -K swauthkey -a Cocos Cocos Cocos -G 'Backup,Bigdata'
swauth-add-user -K swauthkey -a Backup Cocos Cocos -I 'female doctor1 system_structure hust'
swauth-add-user -K swauthkey -a Bigdata Cocos Cocos -I 'female doctor1 security hust'
