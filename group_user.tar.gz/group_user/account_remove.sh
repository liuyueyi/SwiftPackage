#!/bin/bash
cat ac.txt | while read line
do swauth-delete-account -K swauthkey $line
echo "over"
done
