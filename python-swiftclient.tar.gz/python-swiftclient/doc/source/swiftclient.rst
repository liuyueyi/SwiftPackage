.. _swiftclient_package:

swiftclient
==============

.. automodule:: swiftclient

swiftclient.client
==================

.. automodule:: swiftclient.client

swiftclient.exceptions
======================

.. automodule:: swiftclient.exceptions

swiftclient.multithreading
==========================

.. automodule:: swiftclient.multithreading
